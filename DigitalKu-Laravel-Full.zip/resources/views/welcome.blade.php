<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DigitalKu</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <h1>Selamat Datang di DigitalKu</h1>
  <div>
    <h2>Produk A</h2>
    <p>Harga: Rp 10.000</p>
    <button onclick="checkout()">Beli</button>
  </div>
  <script src="/js/script.js"></script>
</body>
</html>
