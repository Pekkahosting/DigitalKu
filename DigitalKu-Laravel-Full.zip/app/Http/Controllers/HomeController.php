<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        return view('welcome');
    }

    public function checkout(Request $request)
    {
        // Simpan ke sesi atau dummy DB
        return response()->json(['status' => 'pending', 'message' => 'Menunggu konfirmasi admin.']);
    }

    public function approve(Request $request)
    {
        // Admin menyetujui pembayaran
        return response()->json(['status' => 'approved']);
    }
}
