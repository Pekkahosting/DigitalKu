<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

Route::get('/', [HomeController::class, 'index']);
Route::post('/checkout', [HomeController::class, 'checkout']);
Route::post('/admin/approve', [HomeController::class, 'approve']);
